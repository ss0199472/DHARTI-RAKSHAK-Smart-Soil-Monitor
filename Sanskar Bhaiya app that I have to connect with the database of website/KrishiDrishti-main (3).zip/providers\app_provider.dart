import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/soil_scan.dart';
import '../services/database_service.dart';

/// Single source of truth for app state: language selection,
/// live cloud database connection status, telemetry data, and scan history.
class AppProvider extends ChangeNotifier {
  static const _kLanguageKey = 'isHindi';
  static const _kOnboardedKey = 'hasChosenLanguage';
  static const _kHistoryKey = 'scanHistory';

  bool _isHindi = false;
  bool _hasChosenLanguage = false;
  bool _isDatabaseConnected = false;
  bool _isDeviceOnline = false;
  bool _isCheckingConnection = false;
  bool _autoRefreshEnabled = true;
  DateTime? _lastSyncTime;
  String _deviceStatusText = 'OFFLINE';
  String _deviceIp = '--';

  List<SoilScan> _history = [];
  bool _isLoaded = false;
  SoilScan? _liveTelemetry;

  Timer? _pollingTimer;

  bool get isHindi => _isHindi;
  bool get hasChosenLanguage => _hasChosenLanguage;
  bool get isDatabaseConnected => _isDatabaseConnected;
  bool get isDeviceOnline => _isDeviceOnline;
  bool get isCheckingConnection => _isCheckingConnection;
  bool get autoRefreshEnabled => _autoRefreshEnabled;
  DateTime? get lastSyncTime => _lastSyncTime;
  String get deviceStatusText => _deviceStatusText;
  String get deviceIp => _deviceIp;
  List<SoilScan> get history => List.unmodifiable(_history);
  bool get isLoaded => _isLoaded;
  SoilScan? get liveTelemetry => _liveTelemetry;
  SoilScan? get lastScan => _liveTelemetry ?? (_history.isEmpty ? null : _history.first);

  Future<void> loadFromDisk() async {
    final prefs = await SharedPreferences.getInstance();
    _isHindi = prefs.getBool(_kLanguageKey) ?? false;
    _hasChosenLanguage = prefs.getBool(_kOnboardedKey) ?? false;
    _autoRefreshEnabled = prefs.getBool('autoRefreshEnabled') ?? true;

    final raw = prefs.getStringList(_kHistoryKey) ?? [];
    _history = raw
        .map((s) => SoilScan.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));

    _isLoaded = true;
    notifyListeners();

    // Start background polling to the website database if enabled
    if (_autoRefreshEnabled) {
      startLiveDatabaseSync();
    } else {
      checkDatabaseConnection();
    }
  }

  /// Toggle auto-refresh on or off and persist preference
  Future<void> toggleAutoRefresh([bool? enable]) async {
    _autoRefreshEnabled = enable ?? !_autoRefreshEnabled;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('autoRefreshEnabled', _autoRefreshEnabled);

    if (_autoRefreshEnabled) {
      startLiveDatabaseSync();
    } else {
      _pollingTimer?.cancel();
      _pollingTimer = null;
    }
  }

  /// Start automatic synchronization with the website Firebase database
  void startLiveDatabaseSync() {
    _pollingTimer?.cancel();
    // Immediate initial sync
    checkDatabaseConnection();
    // Poll every 2.5 seconds for instant live updates
    _pollingTimer = Timer.periodic(const Duration(milliseconds: 2500), (_) {
      if (_autoRefreshEnabled) {
        checkDatabaseConnection(silent: true);
      }
    });
  }

  /// Query the database for live node status and latest telemetry
  Future<void> checkDatabaseConnection({bool silent = false}) async {
    if (!silent) {
      _isCheckingConnection = true;
      notifyListeners();
    }

    try {
      final status = await DatabaseService.fetchDeviceStatus();
      final isOnline = status['online'] == true;
      _isDatabaseConnected = true; // Connection to database server succeeded
      _isDeviceOnline = isOnline;
      _deviceIp = status['ip'] ?? '--';
      _deviceStatusText = status['sensorStatus'] ?? (isOnline ? 'HEALTHY' : 'OFFLINE');

      if (isOnline) {
        final latest = await DatabaseService.fetchLatestTelemetry(isHindi: _isHindi);
        if (latest != null) {
          _liveTelemetry = latest;
        } else {
          // If telemetry is null, device timed out
          _isDeviceOnline = false;
          _liveTelemetry = null;
          _deviceStatusText = 'OFFLINE';
        }
      } else {
        _liveTelemetry = null;
      }
      _lastSyncTime = DateTime.now();
    } catch (e) {
      debugPrint('[AppProvider] checkDatabaseConnection error: $e');
      _isDatabaseConnected = false;
      _isDeviceOnline = false;
      _liveTelemetry = null;
      _deviceStatusText = 'OFFLINE';
    } finally {
      _isCheckingConnection = false;
      notifyListeners();
    }
  }

  /// Trigger a live snapshot from the database and record it to local history
  Future<SoilScan?> captureLiveReading() async {
    _isCheckingConnection = true;
    notifyListeners();

    try {
      final status = await DatabaseService.fetchDeviceStatus();
      final isOnline = status['online'] == true;
      _isDeviceOnline = isOnline;

      if (!isOnline) {
        _liveTelemetry = null;
        _deviceStatusText = 'OFFLINE';
        _isCheckingConnection = false;
        notifyListeners();
        return null;
      }

      final reading = await DatabaseService.fetchLatestTelemetry(isHindi: _isHindi);
      if (reading != null) {
        _liveTelemetry = reading;
        await addScan(reading);
        _isCheckingConnection = false;
        notifyListeners();
        return reading;
      }
    } catch (e) {
      debugPrint('[AppProvider] captureLiveReading error: $e');
    }

    _isCheckingConnection = false;
    notifyListeners();
    return null;
  }

  Future<void> setLanguage(bool hindi) async {
    _isHindi = hindi;
    _hasChosenLanguage = true;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kLanguageKey, hindi);
    await prefs.setBool(_kOnboardedKey, true);
  }

  Future<void> addScan(SoilScan scan) async {
    _history = [scan, ..._history];
    notifyListeners();
    await _saveHistory();
  }

  Future<void> clearHistory() async {
    _history = [];
    notifyListeners();
    await _saveHistory();
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = _history.map((s) => jsonEncode(s.toJson())).toList();
    await prefs.setStringList(_kHistoryKey, raw);
  }

  @override
  void dispose() {
    _pollingTimer?.cancel();
    super.dispose();
  }
}
