import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'utils/app_strings.dart';
import 'result_page.dart';

/// Fetches real-time telemetry directly from the Dharti Rakshak Firebase database,
/// replacing the mock/simulated random sensor data generator.
class ScanPage extends StatefulWidget {
  const ScanPage({super.key});

  @override
  State<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends State<ScanPage> {
  String? _errorMessage;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchLiveReading();
  }

  Future<void> _fetchLiveReading() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    final app = context.read<AppProvider>();
    final scan = await app.captureLiveReading();

    if (!mounted) return;

    if (scan != null) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultPage(scan: scan, isNewScan: true),
        ),
      );
    } else {
      setState(() {
        _isLoading = false;
        _errorMessage = app.isHindi
            ? 'डिवाइस ऑफलाइन है या डेटाबेस से कनेक्शन विफल रहा।'
            : 'Device is offline or connection to the database failed.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final s = AppStrings(app.isHindi);

    return Scaffold(
      backgroundColor: const Color(0xFF2E7D32),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (_isLoading) ...[
                const SizedBox(
                  width: 100,
                  height: 100,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 4,
                      ),
                      Icon(Icons.cloud_sync, color: Colors.white, size: 44),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                Text(
                  s.scanning,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  s.scanningSub,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
              ] else if (_errorMessage != null) ...[
                const Icon(Icons.cloud_off, color: Colors.white, size: 64),
                const SizedBox(height: 20),
                const Text(
                  'Connection Failed',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  _errorMessage!,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
                const SizedBox(height: 30),
                ElevatedButton.icon(
                  onPressed: _fetchLiveReading,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Retry Connection'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF2E7D32),
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Back to Home', style: TextStyle(color: Colors.white)),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
