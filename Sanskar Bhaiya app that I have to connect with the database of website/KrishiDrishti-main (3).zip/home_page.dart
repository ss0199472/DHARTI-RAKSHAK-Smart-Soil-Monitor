import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'utils/app_strings.dart';
import 'widgets/primary_button.dart';
import 'scan_page.dart';
import 'result_page.dart';
import 'history_page.dart';
import 'chat_page.dart';
import 'settings_page.dart';

class HomePage extends StatefulWidget {
  final bool? isHindi;
  const HomePage({super.key, this.isHindi});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    if (widget.isHindi != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<AppProvider>().setLanguage(widget.isHindi!);
      });
    }
  }

  void _triggerRefresh(AppProvider app) {
    app.checkDatabaseConnection();
  }

  void _startFetch(BuildContext context, AppProvider app, AppStrings s) {
    if (!app.isDeviceOnline) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(s.connectFirst),
          backgroundColor: Colors.red.shade700,
          action: SnackBarAction(
            label: s.connect,
            textColor: Colors.white,
            onPressed: () => app.checkDatabaseConnection(),
          ),
        ),
      );
      return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ScanPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final s = AppStrings(app.isHindi);
    final reading = app.lastScan;

    return Scaffold(
      appBar: AppBar(
        title: Text(s.appName),
        actions: [
          IconButton(
            icon: Icon(
              app.autoRefreshEnabled ? Icons.sync : Icons.sync_disabled,
              color: app.autoRefreshEnabled ? Colors.lightGreenAccent : Colors.white60,
            ),
            tooltip: '${s.autoRefresh}: ${app.autoRefreshEnabled ? "ON" : "OFF"}',
            onPressed: () {
              final newState = !app.autoRefreshEnabled;
              context.read<AppProvider>().toggleAutoRefresh(newState);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    newState
                        ? '🔄 ${s.autoRefresh}: ON (Syncing every 2.5s)'
                        : '⏸️ ${s.autoRefresh}: OFF',
                  ),
                  duration: const Duration(seconds: 2),
                ),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.history),
            tooltip: s.viewHistory,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryPage()),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            tooltip: s.settings,
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => app.checkDatabaseConnection(),
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '🌱 ${s.welcome}',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 6),
              Text(
                s.homeSubtitle,
                style: TextStyle(color: Colors.grey.shade700, fontSize: 14),
              ),
              const SizedBox(height: 18),

              // Cloud Device Status Card (Replacing Bluetooth with Cloud Database status)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 22,
                        backgroundColor: app.isDeviceOnline
                            ? Colors.green
                            : Colors.redAccent,
                        child: Icon(
                          app.isDeviceOnline
                              ? Icons.cloud_done
                              : Icons.cloud_off,
                          color: Colors.white,
                          size: 24,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              s.deviceStatus,
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              app.isDeviceOnline ? s.connected : s.notConnected,
                              style: TextStyle(
                                color: app.isDeviceOnline
                                    ? Colors.green.shade700
                                    : Colors.red.shade700,
                                fontWeight: FontWeight.w500,
                                fontSize: 13,
                              ),
                            ),
                            if (app.isDeviceOnline && app.deviceIp != '--')
                              Text(
                                'IP: ${app.deviceIp}',
                                style: TextStyle(color: Colors.grey.shade600, fontSize: 11),
                              ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 90,
                        child: OutlinedButton(
                          onPressed: app.isCheckingConnection ? null : () => _triggerRefresh(app),
                          child: app.isCheckingConnection
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : Text(s.disconnect),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 16),

              PrimaryButton(
                label: s.startScan,
                icon: Icons.sensors,
                onPressed: () => _startFetch(context, app, s),
              ),

              const SizedBox(height: 12),

              PrimaryButton(
                label: s.askAssistant,
                icon: Icons.chat_bubble_outline,
                color: const Color(0xFF558B2F),
                height: 50,
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ChatPage()),
                ),
              ),

              const SizedBox(height: 26),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    s.lastScan,
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  if (app.autoRefreshEnabled && app.isDeviceOnline)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        border: Border.all(color: Colors.green.shade300),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: const BoxDecoration(
                              color: Colors.green,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            s.autoRefreshLive,
                            style: TextStyle(
                              color: Colors.green.shade800,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 12),

              if (reading == null || !app.isDeviceOnline)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(22),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.sensors_off,
                          size: 40,
                          color: Colors.grey.shade400,
                        ),
                        const SizedBox(height: 12),
                        Text(
                          s.noScansYet,
                          style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                )
              else
                Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(18),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ResultPage(scan: reading, isNewScan: false),
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(s.soilHealth, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: _statusColor(reading.healthStatus).withValues(alpha: 0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  reading.healthStatus,
                                  style: TextStyle(
                                    color: _statusColor(reading.healthStatus),
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Divider(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              _ValueColumn(title: s.moisture, value: '${reading.moisture.toStringAsFixed(1)}%'),
                              _ValueColumn(title: 'pH', value: reading.ph.toStringAsFixed(2)),
                              _ValueColumn(title: s.temperature, value: '${reading.temperature.toStringAsFixed(1)}°C'),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: Colors.green.shade50,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Text('N: ${reading.nitrogen} mg/kg', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                Text('P: ${reading.phosphorus} mg/kg', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                Text('K: ${reading.potassium} mg/kg', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${s.fertility}: ${reading.fertility}', style: TextStyle(fontSize: 13, color: Colors.grey.shade700)),
                              Text('${s.soilType}: ${reading.soilType}', style: TextStyle(fontSize: 13, color: Colors.grey.shade700)),
                            ],
                          ),
                          if (app.lastSyncTime != null) ...[
                            const SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Icon(
                                  Icons.sync,
                                  size: 13,
                                  color: app.autoRefreshEnabled ? Colors.green.shade600 : Colors.grey,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  '${s.lastUpdated}: ${reading.formattedTime}',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: Colors.grey.shade600,
                                    fontStyle: FontStyle.italic,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'Healthy':
      case 'स्वस्थ':
        return Colors.green;
      case 'Poor':
      case 'खराब':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
}

class _ValueColumn extends StatelessWidget {
  final String title;
  final String value;
  const _ValueColumn({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 2),
        Text(title, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
      ],
    );
  }
}
