import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/soil_scan.dart';
import 'recommendation_engine.dart';

/// Service that directly interacts with the Dharti Rakshak Firebase Realtime Database
/// matching the website's data structure and offline detection logic.
class DatabaseService {
  static const String databaseUrl =
      'https://dharti-rakshak-iot-59952-default-rtdb.asia-southeast1.firebasedatabase.app';
  static const String activeDeviceId = 'dharti-node-01';

  // Device considered offline if no heartbeat within 12 seconds
  static const int offlineTimeoutMs = 12000;

  /// Fetches device online status from /devices/{deviceId}/status.json
  static Future<Map<String, dynamic>> fetchDeviceStatus() async {
    try {
      final url = Uri.parse('$databaseUrl/devices/$activeDeviceId/status.json');
      final response = await http.get(url).timeout(const Duration(seconds: 7));

      if (response.statusCode == 200 && response.body != 'null') {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final lastSeen = (data['lastSeen'] as num?)?.toInt() ?? 0;
        final now = DateTime.now().millisecondsSinceEpoch;
        final isRecent = (now - lastSeen) < offlineTimeoutMs;

        return {
          'online': isRecent,
          'ip': data['ip']?.toString() ?? '--',
          'rssi': data['rssi']?.toString() ?? '--',
          'sensorStatus': data['sensorStatus']?.toString() ?? (isRecent ? 'HEALTHY' : 'OFFLINE'),
          'firmwareVersion': data['firmwareVersion']?.toString() ?? '--',
        };
      }
    } catch (e) {
      debugPrint('[DatabaseService] fetchDeviceStatus error: $e');
    }

    return {
      'online': false,
      'ip': '--',
      'rssi': '--',
      'sensorStatus': 'OFFLINE',
      'firmwareVersion': '--',
    };
  }

  /// Fetches live telemetry from /devices/{deviceId}/latest.json
  /// Returns a populated [SoilScan] if the device is reachable and data is fresh,
  /// or null if the device is offline/failed.
  static Future<SoilScan?> fetchLatestTelemetry({required bool isHindi}) async {
    try {
      final url = Uri.parse('$databaseUrl/devices/$activeDeviceId/latest.json');
      final response = await http.get(url).timeout(const Duration(seconds: 7));

      if (response.statusCode == 200 && response.body != 'null') {
        final data = jsonDecode(response.body) as Map<String, dynamic>;

        if (data['moisture'] != null) {
          final rawTs = data['timestamp'];
          int timestampMs = 0;
          if (rawTs is int) {
            timestampMs = rawTs;
          } else if (rawTs is String) {
            timestampMs = DateTime.tryParse(rawTs)?.millisecondsSinceEpoch ?? 0;
          }
          final now = DateTime.now().millisecondsSinceEpoch;
          final isFresh = (now - timestampMs) < offlineTimeoutMs;

          // If offline/stale, treat as offline
          if (!isFresh && timestampMs > 0) {
            debugPrint('[DatabaseService] Telemetry is stale (>12s old)');
            return null;
          }

          final moisture = (data['moisture'] as num?)?.toDouble() ?? 0.0;
          final temperature = (data['temperature'] as num?)?.toDouble() ?? 0.0;
          final ph = (data['ph'] as num?)?.toDouble() ?? 0.0;
          final nitrogen = (data['nitrogen'] as num?)?.toInt() ?? 0;
          final phosphorus = (data['phosphorus'] as num?)?.toInt() ?? 0;
          final potassium = (data['potassium'] as num?)?.toInt() ?? 0;
          final totalNPK = (data['totalNPK'] as num?)?.toInt() ?? (nitrogen + phosphorus + potassium);

          // Calculate fertility & soilType if not provided
          String fertility = data['fertility']?.toString() ?? '';
          if (fertility.isEmpty) {
            if (totalNPK > 250) {
              fertility = 'HIGH';
            } else if (totalNPK > 120) {
              fertility = 'MEDIUM';
            } else {
              fertility = 'LOW';
            }
          }

          String soilType = data['soilType']?.toString() ?? '';
          if (soilType.isEmpty) {
            if (ph < 1.0) {
              soilType = 'Connecting...';
            } else if (ph < 6.0) {
              soilType = 'Acidic';
            } else if (ph > 7.5) {
              soilType = 'Alkaline';
            } else {
              soilType = 'Neutral';
            }
          }

          // Crop suitability matches website matrix
          final cropSuitability = <String, bool>{
            'wheat': (ph >= 6.0 && ph <= 7.5 && moisture < 35.0),
            'rice': (moisture > 40.0 && ph >= 5.5),
            'maize': (nitrogen > 20 && ph >= 5.8),
            'mustard': (ph >= 6.0 && ph <= 7.5 && moisture >= 20 && moisture <= 38),
          };

          // Generate recommendation
          final recResult = RecommendationEngine.generate(
            moisture: moisture,
            ph: ph,
            temperature: temperature,
            nitrogen: nitrogen,
            phosphorus: phosphorus,
            potassium: potassium,
            isHindi: isHindi,
          );

          return SoilScan(
            timestamp: timestampMs > 0
                ? DateTime.fromMillisecondsSinceEpoch(timestampMs)
                : DateTime.now(),
            moisture: moisture,
            ph: ph,
            temperature: temperature,
            nitrogen: nitrogen,
            phosphorus: phosphorus,
            potassium: potassium,
            totalNPK: totalNPK,
            fertility: fertility,
            soilType: soilType,
            cropSuitability: cropSuitability,
            healthStatus: recResult.healthStatus,
            recommendations: recResult.recommendations,
            sensorStatus: data['sensorStatus']?.toString() ?? 'OK',
          );
        }
      }
    } catch (e) {
      debugPrint('[DatabaseService] fetchLatestTelemetry error: $e');
    }
    return null;
  }
}
