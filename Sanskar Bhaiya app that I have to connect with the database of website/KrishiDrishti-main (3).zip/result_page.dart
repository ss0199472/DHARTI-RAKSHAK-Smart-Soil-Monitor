import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_provider.dart';
import 'models/soil_scan.dart';
import 'utils/app_strings.dart';
import 'widgets/primary_button.dart';
import 'home_page.dart';

class ResultPage extends StatelessWidget {
  final SoilScan scan;
  final bool isNewScan;

  const ResultPage({super.key, required this.scan, this.isNewScan = false});

  Color _statusColor(String status) {
    switch (status) {
      case 'Healthy':
      case 'स्वस्थ':
        return Colors.green;
      case 'Poor':
      case 'खराब':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }

  IconData _statusIcon(String status) {
    switch (status) {
      case 'Healthy':
      case 'स्वस्थ':
        return Icons.check_circle;
      case 'Poor':
      case 'खराब':
        return Icons.error;
      default:
        return Icons.warning_amber_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final s = AppStrings(app.isHindi);
    // Use latest live telemetry if device is online and fresh, otherwise fallback to passed scan
    final currentScan = (app.isDeviceOnline && app.liveTelemetry != null)
        ? app.liveTelemetry!
        : scan;
    final color = _statusColor(currentScan.healthStatus);

    return Scaffold(
      appBar: AppBar(
        title: Text(s.scanResult),
        automaticallyImplyLeading: !isNewScan,
        actions: [
          if (app.autoRefreshEnabled && app.isDeviceOnline)
            Padding(
              padding: const EdgeInsets.only(right: 14),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 7,
                        height: 7,
                        decoration: const BoxDecoration(
                          color: Colors.lightGreenAccent,
                          shape: BoxShape.circle,
                        ),
                      ),
                      const SizedBox(width: 5),
                      const Text(
                        'LIVE',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status Card
            Card(
              color: color.withValues(alpha: 0.08),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    Icon(_statusIcon(currentScan.healthStatus), color: color, size: 40),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            currentScan.healthStatus,
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: color,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              '${s.fertility}: ${currentScan.fertility} · ${s.soilType}: ${currentScan.soilType}',
                              style: TextStyle(color: Colors.grey.shade700, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 18),

            // Primary Physical Metrics
            Row(
              children: [
                Expanded(child: _MetricTile(label: s.moisture, value: '${currentScan.moisture.toStringAsFixed(1)}%', icon: Icons.water_drop)),
                const SizedBox(width: 10),
                Expanded(child: _MetricTile(label: 'pH', value: currentScan.ph.toStringAsFixed(2), icon: Icons.science)),
                const SizedBox(width: 10),
                Expanded(child: _MetricTile(label: s.temperature, value: '${currentScan.temperature.toStringAsFixed(1)}°C', icon: Icons.thermostat)),
              ],
            ),

            const SizedBox(height: 10),

            // NPK Macronutrient Breakdown (Matching website)
            Row(
              children: [
                Expanded(child: _MetricTile(label: s.nitrogen, value: '${currentScan.nitrogen}', icon: Icons.grass, unit: 'mg/kg')),
                const SizedBox(width: 10),
                Expanded(child: _MetricTile(label: s.phosphorus, value: '${currentScan.phosphorus}', icon: Icons.spa, unit: 'mg/kg')),
                const SizedBox(width: 10),
                Expanded(child: _MetricTile(label: s.potassium, value: '${currentScan.potassium}', icon: Icons.compost, unit: 'mg/kg')),
              ],
            ),

            const SizedBox(height: 18),

            // Crop Suitability Matrix
            Text(s.cropSuitability, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _CropBadge(name: app.isHindi ? 'गेहूं (Wheat)' : 'Wheat', suitable: currentScan.cropSuitability['wheat'] ?? (currentScan.ph >= 6.0 && currentScan.ph <= 7.5 && currentScan.moisture < 35.0)),
                _CropBadge(name: app.isHindi ? 'चावल (Rice)' : 'Rice', suitable: currentScan.cropSuitability['rice'] ?? (currentScan.moisture > 40.0 && currentScan.ph >= 5.5)),
                _CropBadge(name: app.isHindi ? 'मक्का (Maize)' : 'Maize', suitable: currentScan.cropSuitability['maize'] ?? (currentScan.nitrogen > 20 && currentScan.ph >= 5.8)),
                _CropBadge(name: app.isHindi ? 'सरसों (Mustard)' : 'Mustard', suitable: currentScan.cropSuitability['mustard'] ?? (currentScan.ph >= 6.0 && currentScan.ph <= 7.5 && currentScan.moisture >= 20 && currentScan.moisture <= 38)),
              ],
            ),

            const SizedBox(height: 24),

            // AI Recommendations List
            Text(s.recommendations, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),

            ...currentScan.recommendations.map(
              (tip) => Card(
                margin: const EdgeInsets.only(bottom: 10),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(tip, style: const TextStyle(fontSize: 14, height: 1.4)),
                ),
              ),
            ),

            const SizedBox(height: 20),

            if (isNewScan)
              PrimaryButton(
                label: s.backToHome,
                icon: Icons.home,
                onPressed: () => Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const HomePage()),
                  (route) => false,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _MetricTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final String? unit;

  const _MetricTile({required this.label, required this.value, required this.icon, this.unit});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF2E7D32), size: 22),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            if (unit != null)
              Text(unit!, style: TextStyle(fontSize: 10, color: Colors.grey.shade600)),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 11, color: Colors.grey.shade700), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}

class _CropBadge extends StatelessWidget {
  final String name;
  final bool suitable;

  const _CropBadge({required this.name, required this.suitable});

  @override
  Widget build(BuildContext context) {
    final bg = suitable ? Colors.green.shade50 : Colors.red.shade50;
    final border = suitable ? Colors.green.shade300 : Colors.red.shade200;
    final text = suitable ? Colors.green.shade800 : Colors.red.shade800;
    final icon = suitable ? Icons.check_circle : Icons.cancel;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: text, size: 16),
          const SizedBox(width: 6),
          Text(name, style: TextStyle(color: text, fontWeight: FontWeight.w600, fontSize: 13)),
        ],
      ),
    );
  }
}
