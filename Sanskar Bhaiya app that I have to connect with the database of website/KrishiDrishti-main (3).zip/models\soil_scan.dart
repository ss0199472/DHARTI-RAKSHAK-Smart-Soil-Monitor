/// Real-time sensor reading and agronomy assessment matching the website telemetry.
class SoilScan {
  final DateTime timestamp;
  final double moisture; // percent (0 - 100)
  final double ph; // 0 - 14
  final double temperature; // Celsius
  final int nitrogen; // mg/kg
  final int phosphorus; // mg/kg
  final int potassium; // mg/kg
  final int totalNPK; // mg/kg
  final String fertility; // HIGH | MEDIUM | LOW
  final String soilType; // Acidic | Alkaline | Neutral
  final Map<String, bool> cropSuitability; // wheat, rice, maize, mustard
  final String healthStatus; // Healthy | Needs Attention | Poor
  final List<String> recommendations;
  final String sensorStatus; // OK | ERROR | HEALTHY

  SoilScan({
    required this.timestamp,
    required this.moisture,
    required this.ph,
    required this.temperature,
    this.nitrogen = 0,
    this.phosphorus = 0,
    this.potassium = 0,
    this.totalNPK = 0,
    this.fertility = 'MEDIUM',
    this.soilType = 'Neutral',
    this.cropSuitability = const {},
    required this.healthStatus,
    required this.recommendations,
    this.sensorStatus = 'OK',
  });

  String get formattedTime {
    final hh = timestamp.hour.toString().padLeft(2, '0');
    final mm = timestamp.minute.toString().padLeft(2, '0');
    final ss = timestamp.second.toString().padLeft(2, '0');
    return '$hh:$mm:$ss';
  }

  String get formattedDateTime {
    final d = timestamp.day.toString().padLeft(2, '0');
    final m = timestamp.month.toString().padLeft(2, '0');
    return '$d/$m/${timestamp.year} · $formattedTime';
  }

  Map<String, dynamic> toJson() => {
        'timestamp': timestamp.toIso8601String(),
        'moisture': moisture,
        'ph': ph,
        'temperature': temperature,
        'nitrogen': nitrogen,
        'phosphorus': phosphorus,
        'potassium': potassium,
        'totalNPK': totalNPK,
        'fertility': fertility,
        'soilType': soilType,
        'cropSuitability': cropSuitability,
        'healthStatus': healthStatus,
        'recommendations': recommendations,
        'sensorStatus': sensorStatus,
      };

  factory SoilScan.fromJson(Map<String, dynamic> json) {
    DateTime parsedTime;
    final rawTs = json['timestamp'];
    if (rawTs is int) {
      parsedTime = DateTime.fromMillisecondsSinceEpoch(rawTs);
    } else if (rawTs is String) {
      parsedTime = DateTime.tryParse(rawTs) ?? DateTime.now();
    } else {
      parsedTime = DateTime.now();
    }

    final n = (json['nitrogen'] as num?)?.toInt() ?? 0;
    final p = (json['phosphorus'] as num?)?.toInt() ?? 0;
    final k = (json['potassium'] as num?)?.toInt() ?? 0;
    final total = (json['totalNPK'] as num?)?.toInt() ?? (n + p + k);

    final rawCrops = json['cropSuitability'];
    final crops = <String, bool>{};
    if (rawCrops is Map) {
      rawCrops.forEach((key, val) {
        crops[key.toString()] = val == true;
      });
    }

    return SoilScan(
      timestamp: parsedTime,
      moisture: (json['moisture'] as num?)?.toDouble() ?? 0.0,
      ph: (json['ph'] as num?)?.toDouble() ?? 0.0,
      temperature: (json['temperature'] as num?)?.toDouble() ?? 0.0,
      nitrogen: n,
      phosphorus: p,
      potassium: k,
      totalNPK: total,
      fertility: json['fertility']?.toString() ?? 'MEDIUM',
      soilType: json['soilType']?.toString() ?? 'Neutral',
      cropSuitability: crops,
      healthStatus: json['healthStatus']?.toString() ?? 'Healthy',
      recommendations: json['recommendations'] != null
          ? List<String>.from(json['recommendations'] as List)
          : <String>[],
      sensorStatus: json['sensorStatus']?.toString() ?? 'OK',
    );
  }

  /// Returns true if new telemetry values differ from another scan
  bool hasDifferentValuesFrom(SoilScan? other) {
    if (other == null) return true;
    return moisture != other.moisture ||
        ph != other.ph ||
        temperature != other.temperature ||
        nitrogen != other.nitrogen ||
        phosphorus != other.phosphorus ||
        potassium != other.potassium ||
        healthStatus != other.healthStatus;
  }
}
