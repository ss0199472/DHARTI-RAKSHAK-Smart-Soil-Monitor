/// Central place for user-facing text supporting English and Hindi.
class AppStrings {
  final bool isHindi;
  const AppStrings(this.isHindi);

  String _t(String en, String hi) => isHindi ? hi : en;

  // Splash
  String get appName => 'KrishiDrishti';
  String get tagline => _t('Smart Soil Analysis', 'स्मार्ट मृदा विश्लेषण');

  // Language page
  String get chooseLanguage => _t('Choose Language', 'भाषा चुनें');
  String get chooseLanguageSub =>
      _t('अपनी भाषा चुनें', 'Choose your language');

  // Home page
  String get welcome => _t('Welcome Farmer!', 'स्वागत है, अन्नदाता!');
  String get homeSubtitle =>
      _t('Live Soil Telemetry & AI Crop Intelligence', 'लाइव मिट्टी डेटा और एआई फसल विश्लेषण');
  String get deviceStatus => _t('IoT Node Status', 'आईओटी नोड स्थिति');
  String get connected => _t('Online (Cloud Connected)', 'ऑनलाइन (क्लाउड से जुड़ा हुआ)');
  String get notConnected => _t('Offline (No Signal)', 'ऑफलाइन (कोई सिग्नल नहीं)');
  String get connect => _t('Sync', 'सिंक करें');
  String get disconnect => _t('Refresh', 'रिफ्रेश');
  String get startScan => _t('Fetch Live Sensor Reading', 'लाइव सेंसर डेटा प्राप्त करें');
  String get lastScan => _t('Live Soil Telemetry', 'लाइव मिट्टी माप');
  String get noScansYet =>
      _t('Waiting for ESP32 live telemetry... Power on the device.', 'ESP32 लाइव डेटा की प्रतीक्षा है... डिवाइस चालू करें।');
  String get viewHistory => _t('View History', 'इतिहास देखें');
  String get askAssistant => _t('Ask KrishiDrishti AI Assistant', 'कृषिदृष्टि एआई सहायक से पूछें');
  String get moisture => _t('Moisture', 'नमी');
  String get soilHealth => _t('Soil Health', 'मिट्टी का स्वास्थ्य');
  String get temperature => _t('Temperature', 'तापमान');
  String get nitrogen => _t('Nitrogen (N)', 'नाइट्रोजन (N)');
  String get phosphorus => _t('Phosphorus (P)', 'फास्फोरस (P)');
  String get potassium => _t('Potassium (K)', 'पोटेशियम (K)');
  String get totalNPK => _t('Total NPK', 'कुल NPK');
  String get fertility => _t('Fertility', 'उर्वरता');
  String get soilType => _t('Soil Type', 'मिट्टी का प्रकार');
  String get cropSuitability => _t('Crop Suitability', 'फसल उपयुक्तता');

  // Scan page
  String get scanning => _t('Fetching Live Sensor Telemetry…', 'लाइव सेंसर डेटा प्राप्त कर रहे हैं…');
  String get scanningSub => _t(
      'Connecting to KrishiDrishti Cloud Database…', 'कृषिदृष्टि क्लाउड डेटाबेस से कनेक्ट हो रहा है…');
  String get connectFirst => _t(
      'IoT Sensor Node is offline. Please power on your ESP32.',
      'आईओटी सेंसर नोड ऑफलाइन है। कृपया ESP32 चालू करें।');

  // Result page
  String get scanResult => _t('Soil Health Telemetry', 'मृदा स्वास्थ्य विश्लेषण');
  String get recommendations => _t('AI Recommendations', 'एआई सुझाव');
  String get healthy => _t('Healthy', 'स्वस्थ');
  String get needsAttention => _t('Needs Attention', 'ध्यान देने की आवश्यकता');
  String get poor => _t('Poor', 'खराब');
  String get backToHome => _t('Back to Dashboard', 'डैशबोर्ड पर वापस जाएं');
  String get savedToHistory =>
      _t('Synced with cloud & saved to history', 'क्लाउड से सिंक और इतिहास में सहेजा गया');

  // History page
  String get scanHistory => _t('Telemetry History', 'डेटा इतिहास');
  String get noHistory => _t('No telemetry recorded yet.', 'अभी तक कोई डेटा दर्ज नहीं हुआ।');
  String get clearHistory => _t('Clear History', 'इतिहास मिटाएं');
  String get clearHistoryConfirm => _t(
      'This will permanently delete all saved readings. Continue?',
      'इससे सभी सहेजे गए माप स्थायी रूप से हट जाएंगे। जारी रखें?');
  String get cancel => _t('Cancel', 'रद्द करें');
  String get delete => _t('Delete', 'हटाएं');
  String get moistureTrend => _t('Moisture Trend', 'नमी का रुझान');

  // Chat assistant
  String get chatTitle => _t('KrishiDrishti Assistant', 'कृषिदृष्टि सहायक');
  String get chatHint => _t(
      'Ask about crops, NPK, irrigation, pests…', 'फसल, NPK, सिंचाई, कीटों के बारे में पूछें…');
  String get chatGreeting => _t(
      'Namaste! I am your KrishiDrishti farming assistant. Ask me anything about soil health, NPK, pH, or crops.',
      'नमस्ते! मैं आपका कृषिदृष्टि सहायक हूँ। मिट्टी के स्वास्थ्य, NPK, pH या फसलों के बारे में कुछ भी पूछें।');

  // Settings
  String get settings => _t('Settings & System Info', 'सेटिंग्स और सिस्टम जानकारी');
  String get language => _t('Language', 'भाषा');
  String get english => _t('English', 'अंग्रेज़ी');
  String get hindi => _t('Hindi', 'हिन्दी');
  String get about => _t('About KrishiDrishti', 'KrishiDrishti के बारे में');
  String get aboutBody => _t(
      'KrishiDrishti helps farmers understand their soil and crops with real-time cloud sensor data and actionable advice.',
      'KrishiDrishti किसानों को रीयल-टाइम क्लाउड सेंसर डेटा और उपयोगी सलाह के साथ उनकी मिट्टी और फसलों को समझने में मदद करता है।');
  String get version => _t('Version', 'संस्करण');
  String get cloudDatabase => _t('Cloud Database', 'क्लाउड डेटाबेस');
}
