/// Rule-based agronomy recommendation engine matching the website rules.
class RecommendationResult {
  final String healthStatus; // Healthy | Needs Attention | Poor
  final List<String> recommendations;

  RecommendationResult(this.healthStatus, this.recommendations);
}

class RecommendationEngine {
  static RecommendationResult generate({
    required double moisture,
    required double ph,
    required double temperature,
    int nitrogen = 0,
    int phosphorus = 0,
    int potassium = 0,
    required bool isHindi,
  }) {
    final issues = <String>[];
    final tips = <String>[];

    // --- Moisture ---
    if (moisture < 20) {
      issues.add('moisture');
      tips.add(isHindi
          ? '💧 मिट्टी बहुत सूखी है (${moisture.toStringAsFixed(1)}%)। जल्द ही सिंचाई करें।'
          : '💧 Soil is very dry (${moisture.toStringAsFixed(1)}%). Irrigate soon.');
    } else if (moisture > 65) {
      issues.add('moisture');
      tips.add(isHindi
          ? '💧 मिट्टी में अधिक नमी है (${moisture.toStringAsFixed(1)}%)। जलभराव से बचने के लिए सिंचाई रोकें।'
          : '💧 Soil moisture is very high (${moisture.toStringAsFixed(1)}%). Hold off irrigation to prevent waterlogging.');
    } else {
      tips.add(isHindi
          ? '💧 नमी का स्तर (${moisture.toStringAsFixed(1)}%) फसलों के लिए उपयुक्त है।'
          : '💧 Moisture level (${moisture.toStringAsFixed(1)}%) is optimal for crop growth.');
    }

    // --- pH ---
    if (ph < 5.5) {
      issues.add('ph');
      tips.add(isHindi
          ? '🧪 मिट्टी अधिक अम्लीय है (pH ${ph.toStringAsFixed(2)})। चूना (agricultural lime) या जैविक खाद मिलाएं।'
          : '🧪 Soil is acidic (pH ${ph.toStringAsFixed(2)}). Add agricultural lime or organic compost to balance pH.');
    } else if (ph > 7.8) {
      issues.add('ph');
      tips.add(isHindi
          ? '🧪 मिट्टी क्षारीय है (pH ${ph.toStringAsFixed(2)})। जिप्सम या जैविक खाद मिलाकर pH कम करें।'
          : '🧪 Soil is alkaline (pH ${ph.toStringAsFixed(2)}). Add gypsum or organic mulch to lower soil pH.');
    } else {
      tips.add(isHindi
          ? '🧪 pH स्तर (${ph.toStringAsFixed(2)}) फसलों के लिए आदर्श श्रेणी में है।'
          : '🧪 pH level (${ph.toStringAsFixed(2)}) is in the ideal biological assimilation range.');
    }

    // --- Temperature ---
    if (temperature < 15) {
      issues.add('temperature');
      tips.add(isHindi
          ? '🌡️ मिट्टी ठंडी है (${temperature.toStringAsFixed(1)}°C)। मल्चिंग से गर्मी बनाए रखें।'
          : '🌡️ Soil temperature is low (${temperature.toStringAsFixed(1)}°C). Mulching is recommended to retain root warmth.');
    } else if (temperature > 35) {
      issues.add('temperature');
      tips.add(isHindi
          ? '🌡️ मिट्टी गर्म है (${temperature.toStringAsFixed(1)}°C)। सिंचाई की आवृत्ति बढ़ाएं।'
          : '🌡️ High soil temperature (${temperature.toStringAsFixed(1)}°C). Increase irrigation frequency and shade if possible.');
    } else {
      tips.add(isHindi
          ? '🌡️ तापमान (${temperature.toStringAsFixed(1)}°C) सामान्य फसल वृद्धि के लिए उपयुक्त है।'
          : '🌡️ Temperature (${temperature.toStringAsFixed(1)}°C) is favorable for plant growth.');
    }

    // --- NPK Nutrients ---
    final totalNPK = nitrogen + phosphorus + potassium;
    if (nitrogen > 0 || phosphorus > 0 || potassium > 0) {
      if (nitrogen < 25) {
        issues.add('nitrogen');
        tips.add(isHindi
            ? '🌿 नाइट्रोजन स्तर कम है ($nitrogen mg/kg)। यूरिया या वर्मीकम्पोस्ट का प्रयोग करें।'
            : '🌿 Nitrogen is low ($nitrogen mg/kg). Supplement with urea or vermicompost for leafy growth.');
      }
      if (phosphorus < 15) {
        issues.add('phosphorus');
        tips.add(isHindi
            ? '🌱 फास्फोरस स्तर कम है ($phosphorus mg/kg)। DAP या रॉक फॉस्फेट का प्रयोग करें।'
            : '🌱 Phosphorus is low ($phosphorus mg/kg). Apply DAP or rock phosphate for root establishment.');
      }
      if (potassium < 30) {
        issues.add('potassium');
        tips.add(isHindi
            ? '🌾 पोटेशियम स्तर कम है ($potassium mg/kg)। MOP (पोटाश) का प्रयोग करें।'
            : '🌾 Potassium is low ($potassium mg/kg). Add MOP (potash) for disease resistance.');
      }

      if (totalNPK > 250) {
        tips.add(isHindi
            ? '⭐ कुल NPK पोषक तत्व ($totalNPK mg/kg): उच्च उर्वरता स्तर।'
            : '⭐ Total NPK ($totalNPK mg/kg): High fertility profile.');
      } else if (totalNPK > 120) {
        tips.add(isHindi
            ? '⭐ कुल NPK पोषक तत्व ($totalNPK mg/kg): मध्यम उर्वरता स्तर।'
            : '⭐ Total NPK ($totalNPK mg/kg): Moderate fertility balance.');
      } else {
        issues.add('fertility');
        tips.add(isHindi
            ? '⚠️ कुल NPK पोषक तत्व ($totalNPK mg/kg): कम उर्वरता, खाद की आवश्यकता है।'
            : '⚠️ Total NPK ($totalNPK mg/kg): Low overall fertility. Supplementation needed.');
      }
    }

    String status;
    if (issues.isEmpty) {
      status = isHindi ? 'स्वस्थ' : 'Healthy';
    } else if (issues.length <= 2) {
      status = isHindi ? 'ध्यान देने की आवश्यकता' : 'Needs Attention';
    } else {
      status = isHindi ? 'खराब' : 'Poor';
    }

    return RecommendationResult(status, tips);
  }
}
